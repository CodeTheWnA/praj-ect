<script src="common/header-footer/header/sidebar.js"></script>
	<div class="bars"><i class="fas fa-bars"></i><span>MENU</div>	
	<div class="sidebar">
		<li class="logo">
			<div class="row">
				<div class="wid-20 prajLogo"><img src="common/images/logoN.png"></div>
				<div class="wid-80 prajTxt"><img src="common/images/prajwalanLogoN.png"></div>
			</div>
			<span class="close"><i class="fas fa-align-left"></i>CLOSE</span>
		</li>
		<hr style="background-color: #1f97ed61; height: 1px;">
		<div class="container">
			<li class="menu-item"><div class="bg2"></div><div class="bg"></div><a href="" class="txt-color"><i class="fas fa-home"></i>HOME</a></li>
			<li class="menu-item"><div class="bg2"></div><div class="bg"></div><a href="" class="txt-color"><i class="fas fa-calendar-alt"></i>EVENTS</a></li>
			<li class="menu-item"><div class="bg2"></div><div class="bg"></div><a href="" class="txt-color"><i class="fas fa-cogs"></i>WORKSHOPS</a></li>
			<li class="menu-item"><div class="bg2"></div><div class="bg"></div><a href="" class="txt-color"><i class="fas fa-handshake"></i>SPONSORS</a></li>	
			<li class="menu-item"><div class="bg2"></div><div class="bg"></div><a href="" class="txt-color"><i class="fas fa-images"></i>GALLERY</a></li>
			<li class="menu-item"><div class="bg2"></div><div class="bg"></div><a href="" class="txt-color"><i class="fas fa-users"></i>CONTACT US</a></li>	
			<li class="menu-item"><div class="bg2"></div><div class="bg"></div><a href="" class="txt-color"><i class="fas fa-info-circle"></i>ABOUT US</a></li>
		</div>
	</div>	