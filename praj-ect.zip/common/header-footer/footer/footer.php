
<div class="footer wid-100 blur">
		<div class="wid-40 social-media">
			<div class="row">
				<div class="icon"><a href=""><i class="fab fa-youtube"></i><span class="write" style="background-color: #ff0000;">WATCH</span></a></div>
				<div class="icon"><a href=""><i class="fab fa-google-play"></i><span class="write" style="background-color: #689f38;">DOWNLOAD</span></a></div>
				<div class="icon"><a href=""><i class="fab fa-facebook-f"></i><span class="write" style="background-color: #4267b2;">CONNECT</span></a></div>
				<div class="icon"><a href=""><i class="fab fa-instagram"></i><span class="write" style="background-color: #d10869;">CONNECT</span></a></div>
				<div class="icon"><a href=""><i class="fab fa-twitter"></i><span class="write" style="background-color:#1da1f2;">CONNECT</span></a></div>
				<div class="icon"><a href=""><i class="fab fa-google-plus"></i><span class="write" style="background-color: #de5f54;">CONNECT</span></a></div>
			</div>
		</div>
	</div>